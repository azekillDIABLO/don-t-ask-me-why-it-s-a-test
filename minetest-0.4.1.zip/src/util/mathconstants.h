#include <math.h>

// MSVC doesn't seem to define this
#ifndef M_PI
	#define M_PI 3.1415926535
#endif

